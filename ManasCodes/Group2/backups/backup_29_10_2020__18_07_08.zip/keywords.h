// ID: 2017B5A70546P Name: Manas Mishra
// ID: 2017B4A70583P Name: Dhruv Patel
// ID: 2017B3A70783P Name: Bhavya Gera
// ID: 2017B3A70599P Name: Ayush Agrawal
"program",
"(",
")",
"{",
"}",
"]",
"[",
"declare",
"list",
"of",
"variables",
":",
";",
"integer",
"real",
"Boolean",
"boolean",
"jagged",
"array",
"R1",
"size",
"values",
"|||",
"&&&"

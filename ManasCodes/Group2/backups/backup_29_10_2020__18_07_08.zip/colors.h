// ID: 2017B5A70546P Name: Manas Mishra
// ID: 2017B4A70583P Name: Dhruv Patel
// ID: 2017B3A70783P Name: Bhavya Gera
// ID: 2017B3A70599P Name: Ayush Agrawal
#define BOLD_RED printf("\033[1;31m")
#define BOLD_GREEN printf("\033[1;32m")
#define BOLD_YELLOW printf("\033[1;33m")
#define BOLD_BLUE printf("\033[1;34m")
#define BOLD_MAGENTA printf("\033[1;35m")
#define BOLD_CYAN printf("\033[1;36m")
#define RED printf("\033[0;31m")
#define GREEN printf("\033[0;32m")
#define YELLOW printf("\033[0;33m")
#define BLUE printf("\033[0;34m")
#define MAGENTA printf("\033[0;35m")
#define CYAN printf("\033[0;36m")
#define CLEAR_COLORS printf("\033[0m")
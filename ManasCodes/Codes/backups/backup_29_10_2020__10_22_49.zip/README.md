# USAGE
```bash
gcc test.c
./a.out
```
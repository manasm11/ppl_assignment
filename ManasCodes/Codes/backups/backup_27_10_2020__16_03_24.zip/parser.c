
Node *root;
int main(int argc, char const *argv[])
{
    initialize_grammar("grammar_test.txt");
    initialize_token_stream("src_code_test.txt");
    // pGrammars(grammars);
    // pTokens(head);
    // create_parse_tree(grammars)
    // root = 
    return 0;
}
